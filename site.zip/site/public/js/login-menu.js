$(document).ready(function() {
  $('.profile-box>a').click(function() {
    $('.profile-box>a').removeClass('active');
    if ($(this).next('.dropMenu').css("display") == "none") {
      $('.dropMenu').hide('normal');
      $(this).next('.dropMenu').toggle('normal');
    }else{
    	$('.dropMenu').hide('normal');
    	return false;
	}
  });
});