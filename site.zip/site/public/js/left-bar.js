$(document).ready(function() {
	$('#btn-menu').click(function() { // event

		if ($(".left-main-menu").attr("class") === ("left-main-menu")) { // open button

		$(".left-main-menu").toggleClass("active-lmm");
		$(".left-main-menu").toggleClass("left-main-menu");

		}else{ // close button

		$(".active-lmm").toggleClass("left-main-menu");
		$(".active-lmm").toggleClass("active-lmm");
		}

	});

	if($(".left-main-menu").attr("class") === ("left-main-menu")){ // close everywhere

			$(document).on('click','.row',function(){
				$(".active-lmm").toggleClass("left-main-menu");
				$(".active-lmm").toggleClass("active-lmm");
			}
			
	)};
});