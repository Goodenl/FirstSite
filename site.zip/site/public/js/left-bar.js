$(document).ready(function() {
	$('#btn-menu').click(function() {

		if ($(".left-main-menu").attr("class") === ("left-main-menu")) {

		$(".left-main-menu").toggleClass("active-lmm");
		$(".left-main-menu").toggleClass("left-main-menu");

		}else{

		$(".active-lmm").toggleClass("left-main-menu");
		$(".active-lmm").toggleClass("active-lmm");
		}

	});
});