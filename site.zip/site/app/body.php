<?php require_once 'includes/config.php';include_once "includes/db.php"?>
<!DOCTYPE html>
<html lang="ru">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>PolskaPizda</title>

	<link rel="shortcut icon" href="pic/icon/icon.jpeg" type="image/x-icon">

	<link rel="stylesheet" type="text/css" href="public/css/body.css">
	<link rel="stylesheet" type="text/css" href="public/css/top-main-menu.css">
	<link rel="stylesheet" type="text/css" href="public/css/left-main-menu.css">
	<link rel="stylesheet" type="text/css" href="public/css/active-lmm.css">
	<link rel="stylesheet" type="text/css" href="public/css/login-form.css">

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript" src="public/js/login-menu.js"></script>
	<script type="text/javascript" src="public/js/left-bar.js"></script>
</head>
<body>
	<?php require_once 'app/left-main-menu.php'?>
	<?php require_once 'app/top-main-menu.php'?>
	<div id = "video">
		<?php require 'app/video.php'?>
			
	</div>
</body>
</html>