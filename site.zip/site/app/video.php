<?php

	require_once "/domains/site/includes/config.php";
	require_once "/domains/site/includes/db.php";
	session_start();
	$video_title = R::getAssoc( 'SELECT `id`, `title` FROM `video`' );

	$startFrom = $_GET['startFrom'];
	if ($startFrom >= count($video_title)){
		die;
	}
?>
<div class="row">
	<div class="video">
		<div id="title"><a href=<?php $startFrom++; echo "player/video-player.php?v=" . $video_title[$startFrom]; ?>><?php  echo $video_title[$startFrom]; ?></a></div>
		<div id=""></div>
		<div id=""></div>
		<div id="rating"><p></p></div>
	</div>
	<div class="video">
		<div id="title"><a href=<?php $startFrom++; echo "player/video-player.php?v=" . $video_title[$startFrom]; ?>><?php  echo $video_title[$startFrom]; ?></a></div>
		<div id=""></div>
		<div id=""></div>
		<div id="rating"><p></p></div>
	</div>
	<div class="video">
		<div id="title"><a href=<?php $startFrom++; echo "player/video-player.php?v=" . $video_title[$startFrom]; ?>><?php  echo $video_title[$startFrom]; ?></a></div>
		<div id=""></div>
		<div id=""></div>
		<div id="rating"><p></p></div>
	</div>
</div>
<div class="row">
	<div class="video">
		<div id="title"><a href=<?php $startFrom++; echo "player/video-player.php?v=" . $video_title[$startFrom]; ?>><?php  echo $video_title[$startFrom]; ?></a></div>
		<div id=""></div>
		<div id=""></div>
		<div id="rating"><p></p></div>
	</div>
	<div class="video">
		<div id="title"><a href=<?php $startFrom++; echo "player/video-player.php?v=" . $video_title[$startFrom]; ?>><?php  echo $video_title[$startFrom]; ?></a></div>
		<div id=""></div>
		<div id=""></div>
		<div id="rating"><p></p></div>
	</div>
	<div class="video">
		<div id="title"><a href=<?php $startFrom++; echo "player/video-player.php?v=" . $video_title[$startFrom]; ?>><?php  echo $video_title[$startFrom]; ?></a></div>
		<div id=""></div>
		<div id=""></div>
		<div id="rating"><p></p></div>
	</div>
</div>
<div class="row">
	<div class="video">
		<div id="title"><a href=<?php $startFrom++; echo "player/video-player.php?v=" . $video_title[$startFrom]; ?>><?php  echo $video_title[$startFrom]; ?></a></div>
		<div id=""></div>
		<div id=""></div>
		<div id="rating"><p></p></div>
	</div>
	<div class="video">
		<div id="title"><a href=<?php $startFrom++; echo "player/video-player.php?v=" . $video_title[$startFrom]; ?>><?php  echo $video_title[$startFrom]; ?></a></div>
		<div id=""></div>
		<div id=""></div>
		<div id="rating"><p></p></div>
	</div>
	<div class="video">
		<div id="title"><a href=<?php $startFrom++; echo "player/video-player.php?v=" . $video_title[$startFrom]; ?>><?php  echo $video_title[$startFrom]; ?></a></div>
		<div id=""></div>
		<div id=""></div>
		<div id="rating"><p></p></div>
	</div>
</div>