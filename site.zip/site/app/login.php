<?php
	$data = $_POST;
	if ( isset($data['do_login']) )
	{
	$errors = array();
	
		$user = R::findOne('users', 'login = ?', array($data['login']));
		if ( $user )
		{
			if( $data['password'] == $data['password'] )
			{
				//login
				$_SESSION['logged_user'] = $user;
				echo 'Здраствуйте, '.$data['login']."!";
			}else
			{
				$errors[] = 'Пароль не правильно введён';
			}
		}else
		{
			$errors[] = 'Пользователь с таким логином не существует';
		}

		if( ! empty($errors) )
		{
			echo '<div style="color:red;">'.array_shift($errors).'</div><hr>';
		}
	}
?>


<form id = "login-form" action="index.php" method="POST">
	
	<p>
		<p><strong>Логин</strong>:</p>
		<input type="text" name="login" value="<?php echo @$data['login'];?>">
	</p>
	<p>
		<p><strong>Пароль</strong>:</p>
		<input type="password" name="password" >
	</p>
	<p>
		<button type="sumbit" name="do_login">Войти</button>
	</p>

</form>