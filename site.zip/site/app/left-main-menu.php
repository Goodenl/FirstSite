<div class = "left-main-menu">
	<ul id = "">
		<li id = "home"><p><a href="">Home</p></li></a>
		<li id = "category"><p><a href="">Category</p></li></a>
		<li id = "profle"><p><a href="">Profile</p></li></a>
		<li id = "photo"><p><a href="">Photo</p></li></a>
		<li id = "video"><p><a href="">Video</p></li></a>
		<li id = "about"><p><a href="">About</p></li></a>
		<a><p id="copyra">© 2018</p></a>
	</ul>
</div>