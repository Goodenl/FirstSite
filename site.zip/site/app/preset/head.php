
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>PolskaPizda</title>

	<link rel="shortcut icon" href="../pic/icon/icon.jpeg" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="/site/public/css/main/body.css">
	<link rel="stylesheet" type="text/css" href="/site/public/css/main/left-main-menu.css">
	<link rel="stylesheet" type="text/css" href="/site/public/css/main/active-lmm.css">

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<script type="text/javascript" src="/site/public/js/left-bar.js"></script>