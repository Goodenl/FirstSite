<?php require_once "/domains/site/includes/config.php"; require_once "/domains/site/includes/db.php";?>
<!DOCTYPE html>
<!-- header -->