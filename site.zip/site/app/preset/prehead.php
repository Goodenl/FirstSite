<?php require_once "/domains/localhost/site/includes/config.php"; require_once "/domains/localhost/site/includes/db.php";?>
<!DOCTYPE html>
<!-- header -->