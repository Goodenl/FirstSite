<div id = "top-main-menu">
	
	<button id = "btn-menu"><p id = "menu" ></p></button>
	<div class="profile-box">
		<a href="#">Profile</a>
		<div class="dropMenu">
			<?php if( isset($_SESSION['logged_user']) ) : ?>
				<!-- Logined User -->
				<p id = "prfl-name"><?php echo $data['login'] ?></p>
				<img id = "prfl-img" src ='/site/pic/icon/non-avatar.png'>
				<a href="pages/logout.php">Выход</a>
			<?php else : ?>
				<!-- Non-Logined User -->
				<?php require_once 'app/login.php';?>
				<a href="pages/signup.php">Регистрация</a>
			<?php endif; ?>
		</div>
	</div> 
</div>