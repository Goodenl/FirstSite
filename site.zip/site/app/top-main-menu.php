<div id = "top-main-menu">
	
	
	<div class="profile-box">
		<a id="prfl-btn" href="#">Profile</a>
		<div class="dropMenu">

			<?php if( isset($_SESSION['logged_user']) ) : ?>
				<!-- Logined User -->
				<a href="/site/pages/profile.php">
					<div class="user-profile">
						<img id = "prfl-img" src ='/site/pic/icon/non-avatar.png'>
						<p id = "prfl-name"><?php echo $_POST['login']; ?></p>
					</div>
				</a>
				<a href="/site/pages/logout.php">Выход</a>

			<?php else : ?>
				<!-- Non-Logined User -->
				<?php require '/domains/localhost/site/app/login.php';?>
				<a href="/domains/localhost/site/pages/signup.php">Регистрация</a>

			<?php endif; ?>

		</div>
	</div>
</div>