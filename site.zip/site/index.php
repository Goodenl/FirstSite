<?php
	require 'W:/domains/localhost/site/app/body.php';
?>