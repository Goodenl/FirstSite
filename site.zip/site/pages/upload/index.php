<?php require_once "../../app/preset/prehead.php";?>

<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>
	
<div id="content">
</div>

<form name="form1" action="upload.php" enctype="multipart/form-data" method="post">
		<input type="text" name="cust_name" placeholder="Выберите имя файлa"/></br>
		<?php
		$cat_name = R::getAssoc( 'SELECT `id`, `title` FROM `category`' );
		$count = count($cat_name);
		$count++;


		for ($i=1; $i < $count; $i++) {
				$title = strtolower($cat_name[$i]);
				echo "<input id=\"cat_select\" type=\"radio\" name=\"cat_video\" value=\"".$i."\"/>";
				echo  "<label for=\"cat_select\">$title</label>";
			} echo "<br>"?>
		<input type="file" name="path" title="Выберите первый файл"/></br>
	</br>

<input type="submit" name="button" /></br>

</body>

</html>