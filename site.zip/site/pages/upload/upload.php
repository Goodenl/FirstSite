<?php
require_once "../../includes/config.php"; require_once "../../includes/db.php";
// upload on server
$_FILES['path']['name'] = $_POST['cust_name'] ;

$file = "../upload/".$_FILES['path']['name']. ".mp4";

move_uploaded_file($_FILES['path']['tmp_name'], $file);

	if(isset($_FILES['path']['name'])==true){
		
		echo "Загруженный первый файл: ".$_FILES['path']['name']. ".mp4" ."</br>";
		echo "Размер: ".$_FILES['path']['size']."байт"."</br>";
		echo "<a href = '/plug/uploadeng/'> Exit </a>";
	}
print_r($_POST['cat_video']);
// upload on db

$video = R::dispense('video');

$video->title = $_FILES['path']['name'];
$video->author = $_SESSION['logged_user'];
$video->video_category = strval($_POST['cat_video']);

$id = R::store( $video );