
<?php require_once '../../includes/config.php'; include_once "../../includes/db.php";?>
<div id="cat-box">
	<img id="cat-img" src="" alt="">
	<p id="cat-name"><?php
		$db = mysqli_connect("localhost","root","","polskapizda");
		for ($i=0; $i < 2; $i++) { 
			strval($i);
			echo R::getAll('SELECTE * FROM `title`');
		}
	?></p>
	<button></button>
</div>

<?php //R::getRow( 'SELECT * FROM title WHERE id="1"'); ?>