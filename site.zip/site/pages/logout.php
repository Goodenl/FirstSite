<?php require_once 'W:/domains/site/includes/config.php';include_once "W:/domains/site/includes/db.php";
	session_start();
	unset( $_SESSION['logged_user']);
	header('Location: /');
	R::close();