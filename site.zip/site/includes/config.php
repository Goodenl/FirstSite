<?php
$config = array(
		'title' => 'Главная',
		'db' => array(
			'server' => '127.0.0.1',
			'username' => 'root',
			'password' => '',
			'name' => 'polskapizda'
		)
	);
?>