<?php $dir = "/"; ?>

<button id = "btn-menu"><img src="/pic/icon/PolskaPizda.svg" alt="PolskaPizda" width="50px"></button>
<div class = "left-main-menu">
	<ul id = "">
		<li id = "home"><p><a href=<?php echo $dir ?>>Home</a></p></li>
		<li id = "category"><p><a href=<?php echo $dir."pages/category"?>>Category</a></p></li>
		<li id = "profle"><p><a href=<?php echo $dir."pages/profile" ?>>Profile</a></p></li>
		<li id = "photo"><p><a href="">Photo</a></p></li>
		<li id = "video"><p><a href="">Video</a></p></li>
		<li id = "about"><p><a href="/pages/about.php">About</a></p></li>
		<a><p id="copyra">© 2018</p></a>
	</ul>
</div>