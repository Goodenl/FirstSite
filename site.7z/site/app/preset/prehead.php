<?php require_once "/opt/lampp/htdocs/includes/config.php"; require_once "/opt/lampp/htdocs/includes/db.php";?>
<!DOCTYPE html>
<!-- header -->