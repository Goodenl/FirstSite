
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>PolskaPizda</title>

	<link rel="shortcut icon" href="../pic/icon/PolskaPizda.svg" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="/public/css/main/body.css">
	<link rel="stylesheet" type="text/css" href="/public/css/main/left-main-menu.css">
	<link rel="stylesheet" type="text/css" href="/public/css/main/active-lmm.css">

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<script type="text/javascript" src="/public/js/left-bar.js"></script>