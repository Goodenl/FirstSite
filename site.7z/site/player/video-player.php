<video width="640" height="360" controls>
	<source src=<?php echo "../pages/upload/uploaded_video/". $_GET['v'] . ".mp4"; ?> type="video/mp4">
	<source src=<?php echo "../pages/upload/uploaded_video/". $_GET['v'] . ".webm"; ?> type="video/webm">
	Your browser does not support the video tag.
</video>