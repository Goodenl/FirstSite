<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>About for us</title>
</head>
<body>
	<div>
		<img src="" alt=""></img>
		<p></p>
	</div>
	<div>
		<img src="" alt=""></img>
		<p></p>
	</div>
	<footer></footer>
</body>
</html>