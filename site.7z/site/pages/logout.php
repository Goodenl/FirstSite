<?php require_once '/server/xampp/htdocs/includes/config.php';include_once "/server/xampp/htdocs/includes/db.php";
	session_start();
	unset( $_SESSION['logged_user']);
	header('Location: /');
	R::close();